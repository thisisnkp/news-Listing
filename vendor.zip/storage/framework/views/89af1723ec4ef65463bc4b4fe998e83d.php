

<?php
$entity = $package;
?>

<?php $__env->startSection('title', 'Rows - ' . $entity->name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="page-title">Rows: <?php echo e($entity->name); ?></h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.packages.index')); ?>">Packages</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.columns.index.package', $package)); ?>"><?php echo e($package->name); ?></a></li>
                <li class="breadcrumb-item active">Rows</li>
            </ol>
        </nav>
    </div>
    <div class="btn-group">
        <a href="<?php echo e(route('admin.columns.index.package', $package)); ?>" class="btn btn-outline-primary">
            <i class="fas fa-columns me-2"></i>Manage Columns
        </a>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addRowModal">
            <i class="fas fa-plus me-2"></i>Add Row
        </button>
        <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#importModal">
            <i class="fas fa-file-import me-2"></i>Import
        </button>
    </div>
</div>

<!-- Language Tabs -->
<?php if($languages->count() > 1): ?>
<ul class="nav nav-tabs mb-3" id="langTabs">
    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="nav-item">
        <button class="nav-link <?php echo e($lang->is_default ? 'active' : ''); ?>"
            data-bs-toggle="tab"
            data-lang="<?php echo e($lang->code); ?>"
            type="button">
            <?php echo e($lang->name); ?>

            <?php if($lang->is_default): ?>
            <span class="badge bg-primary ms-1">Default</span>
            <?php endif; ?>
        </button>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <!-- Search Form -->
        <form action="<?php echo e(route('admin.rows.index.package', $package)); ?>" method="GET" class="mb-4">
            <div class="row g-3">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="search" class="form-control" placeholder="Search rows..." value="<?php echo e($search ?? ''); ?>">
                        <?php if($search ?? false): ?>
                        <a href="<?php echo e(route('admin.rows.index.package', $package)); ?>" class="btn btn-outline-secondary" title="Clear search">
                            <i class="fas fa-times"></i>
                        </a>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-primary">Search</button>
                    </div>
                </div>
            </div>
        </form>

        <?php if($rows->count() > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th style="width: 60px">S.No</th>
                        <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($column->name); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th style="width: 120px">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $data = $row->getTranslatedData($defaultLanguage?->code ?? 'en');
                    ?>
                    <tr data-row-id="<?php echo e($row->id); ?>">
                        <td><?php echo e($rows->firstItem() + $loop->index); ?></td>
                        <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="editable-cell"
                            data-column="<?php echo e($column->slug); ?>"
                            data-type="<?php echo e($column->type); ?>"
                            data-translatable="<?php echo e($column->is_translatable ? '1' : '0'); ?>">
                            <?php if($column->type === 'currency'): ?>
                            <?php echo e(App\Models\SiteSetting::get('currency_symbol', '₹')); ?><?php echo e(number_format($data[$column->slug] ?? 0, 2)); ?>

                            <?php elseif($column->type === 'button'): ?>
                            <?php
                            $btnData = $data[$column->slug] ?? '';
                            $parts = explode('|', $btnData);
                            $btnText = $parts[0] ?? 'Button';
                            $btnLink = $parts[1] ?? '#';
                            ?>
                            <a href="<?php echo e($btnLink); ?>" class="btn btn-sm btn-primary" target="_blank"><?php echo e($btnText); ?></a>
                            <br><small class="text-muted"><?php echo e(Str::limit($btnLink, 30)); ?></small>
                            <?php else: ?>
                            <?php echo e($data[$column->slug] ?? '-'); ?>

                            <?php endif; ?>
                        </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td>
                            <button type="button" class="btn btn-sm btn-outline-primary edit-row"
                                data-row='<?php echo json_encode(["id" => $row->id, "data" => $row->data, "translations" => $row->translations->keyBy("language_id")]) ?>'>
                                <i class="fas fa-edit"></i>
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-danger delete-row"
                                data-id="<?php echo e($row->id); ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <?php echo e($rows->links()); ?>

        <?php else: ?>
        <div class="text-center py-5">
            <?php if($search ?? false): ?>
            <i class="fas fa-search fa-4x text-muted mb-3"></i>
            <h4>No Rows Found</h4>
            <p class="text-muted">No rows match your search "<?php echo e($search); ?>".</p>
            <a href="<?php echo e(route('admin.rows.index.package', $package)); ?>" class="btn btn-secondary">
                <i class="fas fa-times me-2"></i>Clear Search
            </a>
            <?php else: ?>
            <i class="fas fa-database fa-4x text-muted mb-3"></i>
            <h4>No Rows Yet</h4>
            <p class="text-muted">Add data rows to this table.</p>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addRowModal">
                <i class="fas fa-plus me-2"></i>Add First Row
            </button>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Add Row Modal -->
<div class="modal fade" id="addRowModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Row</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?php echo e(route('admin.rows.store.package', $package)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <?php if($languages->count() > 1): ?>
                    <ul class="nav nav-pills mb-3">
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item">
                            <button class="nav-link <?php echo e($lang->is_default ? 'active' : ''); ?>"
                                type="button"
                                data-bs-toggle="pill"
                                data-bs-target="#addLang<?php echo e($lang->id); ?>">
                                <?php echo e($lang->name); ?>

                            </button>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>

                    <div class="tab-content">
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane fade <?php echo e($lang->is_default ? 'show active' : ''); ?>" id="addLang<?php echo e($lang->id); ?>">
                            <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-3">
                                <label class="form-label">
                                    <?php echo e($column->name); ?>

                                    <?php if($column->type === 'button'): ?>
                                    <small class="text-muted">(Format: Button Text|https://link.com)</small>
                                    <?php endif; ?>
                                </label>
                                <?php if($column->is_translatable): ?>
                                <?php if($column->type === 'dropdown' && !empty($column->dropdown_options)): ?>
                                <select name="translations[<?php echo e($lang->id); ?>][<?php echo e($column->slug); ?>]" class="form-select">
                                    <option value="">-- Select --</option>
                                    <?php $__currentLoopData = $column->dropdown_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($option); ?>"><?php echo e($option); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php else: ?>
                                <input type="<?php echo e($column->type === 'number' || $column->type === 'currency' ? 'number' : 'text'); ?>"
                                    name="translations[<?php echo e($lang->id); ?>][<?php echo e($column->slug); ?>]"
                                    class="form-control"
                                    <?php echo e($column->type === 'number' || $column->type === 'currency' ? 'step=0.01' : ''); ?>

                                    placeholder="<?php echo e($column->type === 'button' ? 'Buy Now|https://example.com' : ''); ?>">
                                <?php endif; ?>
                                <?php else: ?>
                                <?php if($loop->parent->first): ?>
                                <?php if($column->type === 'dropdown' && !empty($column->dropdown_options)): ?>
                                <select name="data[<?php echo e($column->slug); ?>]" class="form-select">
                                    <option value="">-- Select --</option>
                                    <?php $__currentLoopData = $column->dropdown_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($option); ?>"><?php echo e($option); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php else: ?>
                                <input type="<?php echo e($column->type === 'number' || $column->type === 'currency' ? 'number' : 'text'); ?>"
                                    name="data[<?php echo e($column->slug); ?>]"
                                    class="form-control"
                                    <?php echo e($column->type === 'number' || $column->type === 'currency' ? 'step=0.01' : ''); ?>

                                    placeholder="<?php echo e($column->type === 'button' ? 'Buy Now|https://example.com' : ''); ?>">
                                <?php endif; ?>
                                <?php else: ?>
                                <input type="text" class="form-control" disabled value="(Same for all languages)">
                                <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Row</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Row Modal -->
<div class="modal fade" id="editRowModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Row</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="editRowForm" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <?php if($languages->count() > 1): ?>
                    <ul class="nav nav-pills mb-3">
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item">
                            <button class="nav-link <?php echo e($lang->is_default ? 'active' : ''); ?>"
                                type="button"
                                data-bs-toggle="pill"
                                data-bs-target="#editLang<?php echo e($lang->id); ?>">
                                <?php echo e($lang->name); ?>

                            </button>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>

                    <div class="tab-content">
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tab-pane fade <?php echo e($lang->is_default ? 'show active' : ''); ?>" id="editLang<?php echo e($lang->id); ?>">
                            <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-3">
                                <label class="form-label">
                                    <?php echo e($column->name); ?>

                                    <?php if($column->type === 'button'): ?>
                                    <small class="text-muted">(Format: Button Text|https://link.com)</small>
                                    <?php endif; ?>
                                </label>
                                <?php if($column->is_translatable): ?>
                                <input type="<?php echo e($column->type === 'number' || $column->type === 'currency' ? 'number' : 'text'); ?>"
                                    name="translations[<?php echo e($lang->id); ?>][<?php echo e($column->slug); ?>]"
                                    class="form-control edit-field"
                                    data-lang="<?php echo e($lang->id); ?>"
                                    data-column="<?php echo e($column->slug); ?>"
                                    data-translatable="1"
                                    <?php echo e($column->type === 'number' || $column->type === 'currency' ? 'step=0.01' : ''); ?>>
                                <?php else: ?>
                                <?php if($loop->parent->first): ?>
                                <input type="<?php echo e($column->type === 'number' || $column->type === 'currency' ? 'number' : 'text'); ?>"
                                    name="data[<?php echo e($column->slug); ?>]"
                                    class="form-control edit-field"
                                    data-column="<?php echo e($column->slug); ?>"
                                    data-translatable="0"
                                    <?php echo e($column->type === 'number' || $column->type === 'currency' ? 'step=0.01' : ''); ?>>
                                <?php else: ?>
                                <input type="text" class="form-control" disabled value="(Same for all languages)">
                                <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Import Modal -->
<div class="modal fade" id="importModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Import Data</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="<?php echo e(route('admin.rows.import.package', $package)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Upload CSV or Excel File</label>
                        <input type="file" name="file" class="form-control" accept=".csv,.xlsx,.xls" required>
                    </div>
                    <div class="alert alert-info">
                        <strong>Column Headers:</strong><br>
                        <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <code><?php echo e($column->slug); ?></code><?php echo e(!$loop->last ? ', ' : ''); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <hr>
                        <small>For translations, use: <code>column_langcode</code> (e.g., name_en, name_hi)</small><br>
                        <small>For buttons: <code>Button Text|https://link.com</code></small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Import</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteRowModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Delete Row</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this row?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form id="deleteRowForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Edit Row
    document.querySelectorAll('.edit-row').forEach(btn => {
        btn.addEventListener('click', function() {
            const rowData = JSON.parse(this.dataset.row);
            document.getElementById('editRowForm').action = `/admin/rows/${rowData.id}`;

            // Fill non-translatable fields
            document.querySelectorAll('.edit-field[data-translatable="0"]').forEach(field => {
                const column = field.dataset.column;
                field.value = rowData.data?.[column] || '';
            });

            // Fill translatable fields
            document.querySelectorAll('.edit-field[data-translatable="1"]').forEach(field => {
                const langId = field.dataset.lang;
                const column = field.dataset.column;
                const translation = rowData.translations?.[langId];
                field.value = translation?.translated_data?.[column] || '';
            });

            new bootstrap.Modal(document.getElementById('editRowModal')).show();
        });
    });

    // Delete Row
    document.querySelectorAll('.delete-row').forEach(btn => {
        btn.addEventListener('click', function() {
            document.getElementById('deleteRowForm').action = `/admin/rows/${this.dataset.id}`;
            new bootstrap.Modal(document.getElementById('deleteRowModal')).show();
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\rvr-p\resources\views/admin/rows/index_package.blade.php ENDPATH**/ ?>