

<?php $__env->startSection('title', 'Plans - ' . $package->name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="page-title">Plans for "<?php echo e($package->name); ?>"</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.packages.index')); ?>">Packages</a></li>
                <li class="breadcrumb-item active">Plans</li>
            </ol>
        </nav>
    </div>
    <a href="<?php echo e(route('admin.plans.create', $package)); ?>" class="btn btn-primary">
        <i class="fas fa-plus me-2"></i>Create Plan
    </a>
</div>

<div class="card">
    <div class="card-body">
        <!-- Search Form -->
        <form action="<?php echo e(route('admin.plans.index', $package)); ?>" method="GET" class="mb-4">
            <div class="row g-3">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" name="search" class="form-control" placeholder="Search plans by name, slug, or description..." value="<?php echo e($search ?? ''); ?>">
                        <?php if($search ?? false): ?>
                        <a href="<?php echo e(route('admin.plans.index', $package)); ?>" class="btn btn-outline-secondary" title="Clear search">
                            <i class="fas fa-times"></i>
                        </a>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-primary">Search</button>
                    </div>
                </div>
            </div>
        </form>

        <?php if($plans->count() > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead>
                    <tr>
                        <th style="width: 50px">#</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Services</th>
                        <th>Columns</th>
                        <th>Rows</th>
                        <th>Status</th>
                        <th style="width: 220px">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($plan->id); ?></td>
                        <td>
                            <strong><?php echo e($plan->name); ?></strong>
                            <?php if($plan->description): ?>
                            <br><small class="text-muted"><?php echo e(Str::limit($plan->description, 50)); ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($plan->price): ?>
                            <span class="badge bg-success">₹<?php echo e(number_format($plan->price, 2)); ?></span>
                            <?php else: ?>
                            <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(count($plan->services ?? [])); ?></td>
                        <td><?php echo e($plan->columns_count); ?></td>
                        <td><?php echo e($plan->rows_count); ?></td>
                        <td>
                            <div class="form-check form-switch">
                                <input class="form-check-input toggle-status" type="checkbox"
                                    data-id="<?php echo e($plan->id); ?>"
                                    <?php echo e($plan->is_active ? 'checked' : ''); ?>>
                            </div>
                        </td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <a href="<?php echo e(route('admin.columns.index', $plan)); ?>" class="btn btn-outline-info" title="Columns">
                                    <i class="fas fa-columns"></i>
                                </a>
                                <a href="<?php echo e(route('admin.rows.index', $plan)); ?>" class="btn btn-outline-success" title="Rows">
                                    <i class="fas fa-list"></i>
                                </a>
                                <a href="<?php echo e(route('admin.plans.edit', $plan)); ?>" class="btn btn-outline-primary" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button type="button" class="btn btn-outline-danger delete-btn"
                                    data-id="<?php echo e($plan->id); ?>"
                                    data-name="<?php echo e($plan->name); ?>"
                                    title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <?php echo e($plans->links()); ?>

        <?php else: ?>
        <div class="text-center py-5">
            <?php if($search ?? false): ?>
            <i class="fas fa-search fa-4x text-muted mb-3"></i>
            <h4>No Plans Found</h4>
            <p class="text-muted">No plans match your search "<?php echo e($search); ?>".</p>
            <a href="<?php echo e(route('admin.plans.index', $package)); ?>" class="btn btn-secondary">
                <i class="fas fa-times me-2"></i>Clear Search
            </a>
            <?php else: ?>
            <i class="fas fa-file-alt fa-4x text-muted mb-3"></i>
            <h4>No Plans Yet</h4>
            <p class="text-muted">Create your first plan for this package.</p>
            <a href="<?php echo e(route('admin.plans.create', $package)); ?>" class="btn btn-primary">
                <i class="fas fa-plus me-2"></i>Create Plan
            </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete <strong id="deleteName"></strong>?</p>
                <p class="text-danger"><small>This will also delete all data in this plan.</small></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form id="deleteForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Toggle Status
    document.querySelectorAll('.toggle-status').forEach(function(el) {
        el.addEventListener('change', function() {
            const id = this.dataset.id;
            fetch(`/admin/plans/${id}/toggle`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': window.csrfToken
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        // Success
                    }
                });
        });
    });

    // Delete
    document.querySelectorAll('.delete-btn').forEach(function(el) {
        el.addEventListener('click', function() {
            const id = this.dataset.id;
            const name = this.dataset.name;

            document.getElementById('deleteName').textContent = name;
            document.getElementById('deleteForm').action = `/admin/plans/${id}`;

            new bootstrap.Modal(document.getElementById('deleteModal')).show();
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\rvr-p\resources\views/admin/plans/index.blade.php ENDPATH**/ ?>