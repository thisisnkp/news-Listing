

<?php $__env->startSection('title', isset($plan) ? 'Edit Plan' : 'Create Plan'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="page-title"><?php echo e(isset($plan) ? 'Edit Plan' : 'Create Plan'); ?></h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.packages.index')); ?>">Packages</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.plans.index', $package)); ?>"><?php echo e($package->name); ?> Plans</a></li>
                <li class="breadcrumb-item active"><?php echo e(isset($plan) ? 'Edit' : 'Create'); ?></li>
            </ol>
        </nav>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <i class="fas fa-file-alt me-2"></i>Plan Details
            </div>
            <div class="card-body">
                <form action="<?php echo e(isset($plan) ? route('admin.plans.update', $plan) : route('admin.plans.store', $package)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($plan)): ?>
                    <?php echo method_field('PUT'); ?>
                    <?php endif; ?>

                    <div class="mb-3">
                        <label class="form-label">Plan Name <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('name', $plan->name ?? '')); ?>" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Slug</label>
                        <input type="text" name="slug" class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            value="<?php echo e(old('slug', $plan->slug ?? '')); ?>"
                            placeholder="Auto-generated if empty">
                        <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-text">URL-friendly identifier. Leave empty to auto-generate.</div>
                    </div>

                    <!-- Services Section -->
                    <div class="mb-3" x-data="servicesManager()">
                        <label class="form-label">Services</label>
                        <div class="border rounded p-3 bg-light">
                            <template x-for="(service, index) in services" :key="index">
                                <div class="input-group mb-2">
                                    <input type="text" :name="'services[' + index + ']'" class="form-control"
                                        x-model="services[index]" placeholder="Enter service...">
                                    <button type="button" class="btn btn-outline-danger" @click="removeService(index)">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </template>
                            <button type="button" class="btn btn-outline-primary btn-sm" @click="addService()">
                                <i class="fas fa-plus me-1"></i>Add Service
                            </button>
                        </div>
                        <div class="form-text">Add services included in this plan.</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="3"><?php echo e(old('description', $plan->description ?? '')); ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Price</label>
                        <div class="input-group" style="max-width: 200px;">
                            <span class="input-group-text">₹</span>
                            <input type="number" name="price" step="0.01" min="0"
                                class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('price', $plan->price ?? '')); ?>"
                                placeholder="Optional">
                        </div>
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-text">Leave empty if price should not be displayed.</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Order Button Link</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-link"></i></span>
                            <input type="url" name="order_button_link"
                                class="form-control <?php $__errorArgs = ['order_button_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('order_button_link', $plan->order_button_link ?? '')); ?>"
                                placeholder="https://example.com/order">
                        </div>
                        <?php $__errorArgs = ['order_button_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-text">Link for the "Order Now" button.</div>
                    </div>

                    <!-- Enabled Filters Section -->
                    <div class="mb-3">
                        <label class="form-label">Table Filters</label>
                        <div class="border rounded p-3 bg-light">
                            <p class="text-muted small mb-2">Select which filters to show on the frontend table:</p>
                            <?php
                            $allFilters = [
                            'da' => 'DA (Domain Authority)',
                            'dr' => 'DR (Domain Rating)',
                            'disclaimer' => 'Disclaimer',
                            'backlinks' => 'Backlinks',
                            'indexing' => 'Indexing',
                            'sort_az' => 'A-Z Sorting',
                            'sort_za' => 'Z-A Sorting',
                            ];
                            $enabledFilters = old('enabled_filters', isset($plan) ? ($plan->enabled_filters ?? array_keys($allFilters)) : array_keys($allFilters));
                            ?>
                            <div class="row">
                                <?php $__currentLoopData = $allFilters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-6 col-md-4">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox"
                                            name="enabled_filters[]" value="<?php echo e($key); ?>"
                                            id="filter_<?php echo e($key); ?>"
                                            <?php echo e(in_array($key, $enabledFilters) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="filter_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="form-text">Unchecked filters will be hidden on the table page.</div>
                    </div>

                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="is_active" id="is_active" value="1"
                                <?php echo e(old('is_active', $plan->is_active ?? true) ? 'checked' : ''); ?>>
                            <label class="form-check-label" for="is_active">Active</label>
                        </div>
                        <div class="form-text">Inactive plans won't be visible on the frontend.</div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i><?php echo e(isset($plan) ? 'Update' : 'Create'); ?> Plan
                        </button>
                        <a href="<?php echo e(route('admin.plans.index', $package)); ?>" class="btn btn-outline-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function servicesManager() {
            return {
                services: <?php echo json_encode(old('services', isset($plan) ? $plan->services : []), 512) ?> || [],
                addService() {
                    this.services.push('');
                },
                removeService(index) {
                    this.services.splice(index, 1);
                }
            }
        }
    </script>

    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                <i class="fas fa-info-circle me-2"></i>Info
            </div>
            <div class="card-body">
                <p class="text-muted mb-2">
                    <i class="fas fa-lightbulb me-2 text-warning"></i>
                    After creating a plan, you can add columns and rows.
                </p>
                <hr>
                <p class="text-muted mb-0">
                    <strong>Default Columns:</strong> Name, Price, Remark
                </p>
                <p class="text-muted">
                    You can customize columns after creation.
                </p>
            </div>
        </div>

        <?php if(isset($plan)): ?>
        <div class="card mt-3">
            <div class="card-header">
                <i class="fas fa-link me-2"></i>Quick Links
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('admin.columns.index', $plan)); ?>" class="btn btn-outline-info">
                        <i class="fas fa-columns me-2"></i>Manage Columns
                    </a>
                    <a href="<?php echo e(route('admin.rows.index', $plan)); ?>" class="btn btn-outline-success">
                        <i class="fas fa-list me-2"></i>Manage Rows
                    </a>
                    <a href="<?php echo e(route('plan.show', $plan->slug)); ?>" class="btn btn-outline-primary" target="_blank">
                        <i class="fas fa-external-link-alt me-2"></i>View on Frontend
                    </a>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\rvr-p\resources\views/admin/plans/form.blade.php ENDPATH**/ ?>