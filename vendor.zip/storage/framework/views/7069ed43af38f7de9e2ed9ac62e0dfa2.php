<?php
$currencySymbol = App\Models\SiteSetting::get('currency_symbol', '₹');
$currencyPosition = App\Models\SiteSetting::get('currency_position', 'before');
?>

<?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<?php
$data = $row->getTranslatedData($currentLang ?? 'en');
?>
<tr>
    <?php $__currentLoopData = $table->columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <td class="col-<?php echo e($column->slug); ?>">
        <?php if($column->type === 'currency'): ?>
        <?php
        $price = $data[$column->slug] ?? 0;
        $formattedPrice = number_format($price, 2);
        ?>
        <?php if($currencyPosition === 'before'): ?>
        <?php echo e($currencySymbol); ?><?php echo e($formattedPrice); ?>

        <?php else: ?>
        <?php echo e($formattedPrice); ?><?php echo e($currencySymbol); ?>

        <?php endif; ?>
        <?php elseif($column->type === 'button'): ?>
        <?php
        $btnData = $data[$column->slug] ?? '';
        $parts = explode('|', $btnData);
        $btnText = trim($parts[0] ?? 'Button');
        $btnLink = trim($parts[1] ?? '#');
        ?>
        <?php if($btnText && $btnLink !== '#'): ?>
        <a href="<?php echo e($btnLink); ?>" class="btn-action" target="_blank">
            <?php echo e($btnText); ?> <i class="fas fa-external-link-alt ms-1"></i>
        </a>
        <?php else: ?>
        <span class="text-muted">-</span>
        <?php endif; ?>
        <?php elseif($column->type === 'number'): ?>
        <?php echo e(number_format($data[$column->slug] ?? 0)); ?>

        <?php else: ?>
        <?php echo e($data[$column->slug] ?? '-'); ?>

        <?php endif; ?>
    </td>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr>
    <td colspan="<?php echo e($table->columns->count()); ?>" class="no-results">
        <i class="fas fa-search fa-3x text-muted mb-3"></i>
        <h5>No results found</h5>
        <p class="text-muted">Try adjusting your search or filters.</p>
    </td>
</tr>
<?php endif; ?><?php /**PATH F:\rvr-p\resources\views/frontend/partials/table-rows.blade.php ENDPATH**/ ?>