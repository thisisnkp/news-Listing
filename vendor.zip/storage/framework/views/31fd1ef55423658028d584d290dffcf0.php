

<?php $__env->startSection('title', 'Site Settings'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="page-title">Site Settings</h1>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Settings</li>
            </ol>
        </nav>
    </div>
</div>

<form action="<?php echo e(route('admin.settings.update')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="row">
        <div class="col-lg-8">
            <!-- General Settings -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-cog me-2"></i>General Settings
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Site Name</label>
                        <input type="text" name="site_name" class="form-control"
                            value="<?php echo e($settings['site_name'] ?? 'SmartTable CMS'); ?>">
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Currency Symbol</label>
                            <input type="text" name="currency_symbol" class="form-control"
                                value="<?php echo e($settings['currency_symbol'] ?? '₹'); ?>" maxlength="10">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Currency Position</label>
                            <select name="currency_position" class="form-select">
                                <option value="before" <?php echo e(($settings['currency_position'] ?? 'before') == 'before' ? 'selected' : ''); ?>>Before (₹100)</option>
                                <option value="after" <?php echo e(($settings['currency_position'] ?? 'before') == 'after' ? 'selected' : ''); ?>>After (100₹)</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Homepage Table</label>
                        <select name="homepage_table_id" class="form-select">
                            <option value="">-- Show All Tables --</option>
                            <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tbl->id); ?>" <?php echo e(($settings['homepage_table_id'] ?? '') == $tbl->id ? 'selected' : ''); ?>>
                                <?php echo e($tbl->name); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="form-text">Select a table to display directly on the homepage, or leave empty to show all tables.</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Order Button Text</label>
                        <input type="text" name="order_button_text" class="form-control"
                            value="<?php echo e($settings['order_button_text'] ?? 'Order Now'); ?>"
                            placeholder="Order Now" maxlength="50">
                        <div class="form-text">Text displayed on the order button for all packages. Default: "Order Now"</div>
                    </div>
                </div>
            </div>

            <!-- SEO Settings -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-search me-2"></i>SEO Settings
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Meta Title</label>
                        <input type="text" name="meta_title" class="form-control"
                            value="<?php echo e($settings['meta_title'] ?? ''); ?>"
                            maxlength="60">
                        <div class="form-text">Recommended: 50-60 characters</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Meta Description</label>
                        <textarea name="meta_description" class="form-control" rows="3"
                            maxlength="160"><?php echo e($settings['meta_description'] ?? ''); ?></textarea>
                        <div class="form-text">Recommended: 150-160 characters</div>
                    </div>
                </div>
            </div>

            <!-- Language Settings -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-globe me-2"></i>Active Languages
                </div>
                <div class="card-body">
                    <?php if($languages->count() > 0): ?>
                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox"
                            name="active_languages[]"
                            value="<?php echo e($lang->id); ?>"
                            id="lang<?php echo e($lang->id); ?>"
                            <?php echo e($lang->is_active ? 'checked' : ''); ?>

                            <?php echo e($lang->is_default ? 'disabled checked' : ''); ?>>
                        <label class="form-check-label" for="lang<?php echo e($lang->id); ?>">
                            <?php echo e($lang->name); ?> (<?php echo e($lang->code); ?>)
                            <?php if($lang->is_default): ?>
                            <span class="badge bg-primary ms-1">Default</span>
                            <input type="hidden" name="active_languages[]" value="<?php echo e($lang->id); ?>">
                            <?php endif; ?>
                        </label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <p class="text-muted">No languages configured. <a href="<?php echo e(route('admin.languages.create')); ?>">Add one</a></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <!-- Branding -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-image me-2"></i>Branding
                </div>
                <div class="card-body">
                    <div class="mb-4">
                        <label class="form-label">Site Logo</label>
                        <?php if($logo = App\Models\SiteSetting::getLogo()): ?>
                        <div class="mb-2 p-3 bg-light rounded text-center">
                            <img src="<?php echo e($logo); ?>" alt="Logo" style="max-height: 60px;">
                        </div>
                        <?php endif; ?>
                        <input type="file" name="site_logo" class="form-control" accept="image/*">
                        <div class="form-text">PNG, JPG, SVG. Max 2MB.</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Site Favicon</label>
                        <?php if($favicon = App\Models\SiteSetting::getFavicon()): ?>
                        <div class="mb-2 p-3 bg-light rounded text-center">
                            <img src="<?php echo e($favicon); ?>" alt="Favicon" style="max-height: 32px;">
                        </div>
                        <?php endif; ?>
                        <input type="file" name="site_favicon" class="form-control" accept=".png,.ico">
                        <div class="form-text">PNG or ICO. Max 1MB.</div>
                    </div>
                </div>
            </div>

            <!-- Save Button -->
            <div class="d-grid">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-save me-2"></i>Save Settings
                </button>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\rvr-p\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>