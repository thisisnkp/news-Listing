

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="page-title">Dashboard</h1>
</div>

<!-- Stats Cards -->
<div class="row g-4 mb-4">
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="stats-card bg-gradient-primary">
            <h3><?php echo e($stats['packages_count']); ?></h3>
            <p>Total Packages</p>
            <i class="fas fa-box icon"></i>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="stats-card bg-gradient-success">
            <h3><?php echo e($stats['plans_count']); ?></h3>
            <p>Total Plans</p>
            <i class="fas fa-file-alt icon"></i>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="stats-card bg-gradient-warning">
            <h3><?php echo e($stats['total_rows']); ?></h3>
            <p>Total Rows</p>
            <i class="fas fa-database icon"></i>
        </div>
    </div>
    <div class="col-12 col-sm-6 col-xl-3">
        <div class="stats-card bg-gradient-info">
            <h3><?php echo e($stats['languages']); ?></h3>
            <p>Active Languages</p>
            <i class="fas fa-globe icon"></i>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row g-4 mb-4">
    <div class="col-12 col-lg-6">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="fas fa-bolt me-2"></i>Quick Actions</span>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('admin.packages.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Create New Package
                    </a>
                    <a href="<?php echo e(route('admin.languages.create')); ?>" class="btn btn-outline-primary">
                        <i class="fas fa-globe me-2"></i>Add Language
                    </a>
                    <a href="<?php echo e(route('admin.settings.index')); ?>" class="btn btn-outline-secondary">
                        <i class="fas fa-cog me-2"></i>Site Settings
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="col-12 col-lg-6">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="fas fa-box me-2"></i>Recent Packages</span>
                <a href="<?php echo e(route('admin.packages.index')); ?>" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="card-body p-0">
                <?php if($recentPackages->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Plans</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $recentPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('admin.packages.edit', $package)); ?>" class="text-decoration-none">
                                        <?php echo e($package->name); ?>

                                    </a>
                                </td>
                                <td><?php echo e($package->plans_count); ?></td>
                                <td>
                                    <?php if($package->is_active): ?>
                                    <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                    <span class="badge bg-secondary">Inactive</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="text-center py-4 text-muted">
                    <i class="fas fa-inbox fa-3x mb-3"></i>
                    <p>No packages created yet</p>
                    <a href="<?php echo e(route('admin.packages.create')); ?>" class="btn btn-primary btn-sm">
                        Create Your First Package
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Developer Info -->
<div class="card">
    <div class="card-body text-center py-4">
        <p class="mb-1 text-muted">SmartTable CMS</p>
        <p class="mb-0">
            Developed by <a href="https://infotechzone.in" target="_blank" class="text-primary">InfotechZone</a>
        </p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\rvr-p\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>