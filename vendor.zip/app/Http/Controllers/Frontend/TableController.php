<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Package;
use App\Models\Plan;
use App\Models\Language;
use App\Models\SiteSetting;
use Illuminate\Http\Request;

class TableController extends Controller
{
    public function index()
    {
        // Show only PUBLIC packages on homepage (not private ones)
        $packages = Package::active()
            ->public()
            ->ordered()
            ->withCount('plans')
            ->get();

        $languages = Language::active()->get();
        $defaultLanguage = Language::getDefault();
        $buttonName = SiteSetting::where('key', 'order_button_text')->first()?->value ?? 'View Details';

        return view('frontend.home', compact('packages', 'languages', 'defaultLanguage', 'buttonName'));
    }

    public function showPackage(string $slug)
    {
        $package = Package::where('slug', $slug)
            ->active()
            ->with(['plans' => function ($q) {
                $q->active()->ordered();
            }])
            ->firstOrFail();

        // Check if private package requires token
        if ($package->isPrivate()) {
            $token = request('token');
            if (!$token || $token !== $package->private_token) {
                abort(404, 'Package not found');
            }
        }

        $languages = Language::active()->get();
        $defaultLanguage = Language::getDefault();
        $currentLang = request('lang', $defaultLanguage?->code ?? 'en');
        $buttonName = SiteSetting::where('key', 'order_button_text')->first()?->value ?? 'Order Now';

        // For media type packages, show table view directly
        if ($package->isMedia()) {
            $columns = $package->columns()->ordered()->get();

            // Get columns marked as filterable for dynamic filter display
            $filterableColumns = $columns->where('is_filterable', true);

            $rows = $this->getFilteredRowsForPackage($package, $columns, $currentLang);

            return view('frontend.media-table', compact('package', 'languages', 'defaultLanguage', 'currentLang', 'buttonName', 'columns', 'rows', 'filterableColumns'));
        }

        // For package type, show plans grid
        return view('frontend.package', compact('package', 'languages', 'defaultLanguage', 'currentLang', 'buttonName'));
    }

    public function showPlan(string $slug)
    {
        $plan = Plan::where('slug', $slug)
            ->active()
            ->with(['columns' => function ($q) {
                $q->ordered();
            }])
            ->firstOrFail();

        // Get all available PUBLIC packages for navigation
        $allPackages = Package::active()->public()->ordered()->get();

        $languages = Language::active()->get();
        $defaultLanguage = Language::getDefault();
        $currentLang = request('lang', $defaultLanguage?->code ?? 'en');

        // Get rows with pagination
        $rows = $this->getFilteredRows($plan, $currentLang);

        // For backwards compatibility with table.blade.php
        $table = $plan;
        $allTables = $allPackages;

        return view('frontend.table', compact('plan', 'table', 'rows', 'languages', 'defaultLanguage', 'currentLang', 'allPackages', 'allTables'));
    }

    public function filter(Request $request, string $slug)
    {
        $plan = Plan::where('slug', $slug)
            ->active()
            ->with(['columns' => function ($q) {
                $q->ordered();
            }])
            ->firstOrFail();

        $currentLang = $request->input('lang', Language::getDefault()?->code ?? 'en');
        $rows = $this->getFilteredRows($plan, $currentLang);

        // For backwards compatibility
        $table = $plan;

        // Return HTML for AJAX
        return view('frontend.partials.table-rows', compact('plan', 'table', 'rows', 'currentLang'))->render();
    }

    public function export(string $slug)
    {
        $plan = Plan::where('slug', $slug)
            ->active()
            ->with(['columns' => function ($q) {
                $q->ordered();
            }])
            ->firstOrFail();

        $defaultLanguage = Language::getDefault();
        $currentLang = request('lang', $defaultLanguage?->code ?? 'en');

        $rows = $plan->rows()->with('translations.language')->get();

        // Build CSV content
        $headers = $plan->columns->pluck('name')->toArray();

        $csvContent = implode(',', array_map(function ($h) {
            return '"' . str_replace('"', '""', (string)$h) . '"';
        }, $headers)) . "\n";

        foreach ($rows as $row) {
            $rowData = $row->getTranslatedData($currentLang);
            $values = [];
            foreach ($plan->columns as $column) {
                $value = $rowData[$column->slug] ?? '';

                // Convert to string if not already
                if (is_array($value)) {
                    $value = implode(', ', $value);
                } elseif (!is_string($value)) {
                    $value = (string)$value;
                }

                // Handle button type - just show text without link
                if ($column->type === 'button' && strpos($value, '|') !== false) {
                    $value = explode('|', $value)[0];
                }
                $values[] = '"' . str_replace('"', '""', $value) . '"';
            }
            $csvContent .= implode(',', $values) . "\n";
        }

        $filename = $plan->slug . '_export_' . date('Y-m-d') . '.csv';

        return response($csvContent)
            ->header('Content-Type', 'text/csv; charset=utf-8')
            ->header('Content-Disposition', 'attachment; filename="' . $filename . '"');
    }

    protected function getFilteredRows(Plan $plan, string $langCode)
    {
        $query = $plan->rows()->with('translations.language');

        $search = request('search');
        $sortBy = request('sort_by');
        $sortDir = request('sort_dir', 'asc');
        $priceMin = request('price_min');
        $priceMax = request('price_max');

        // New dropdown filters
        $filterDA = request('filter_da');
        $filterDR = request('filter_dr');
        $filterDisclaimer = request('filter_disclaimer');
        $filterBacklink = request('filter_backlink');
        $filterIndexing = request('filter_indexing');

        // Get all rows first (for filtering by translated content)
        $rows = $query->get();

        // Apply search filter
        if ($search) {
            $rows = $rows->filter(function ($row) use ($search, $langCode) {
                $data = $row->getTranslatedData($langCode);
                foreach ($data as $value) {
                    if (is_string($value) && stripos($value, $search) !== false) {
                        return true;
                    }
                }
                return false;
            });
        }

        // Apply price filter
        if ($priceMin !== null || $priceMax !== null) {
            $rows = $rows->filter(function ($row) use ($priceMin, $priceMax, $langCode) {
                $data = $row->getTranslatedData($langCode);
                $price = $data['price'] ?? 0;

                if ($priceMin !== null && $price < $priceMin) {
                    return false;
                }
                if ($priceMax !== null && $price > $priceMax) {
                    return false;
                }
                return true;
            });
        }

        // Apply DA filter (numeric range)
        if ($filterDA) {
            $rows = $rows->filter(function ($row) use ($filterDA, $langCode) {
                $data = $row->getTranslatedData($langCode);
                $da = (int)($data['da'] ?? 0);
                [$min, $max] = explode('-', $filterDA);
                return $da >= (int)$min && $da <= (int)$max;
            });
        }

        // Apply DR filter (numeric range)
        if ($filterDR) {
            $rows = $rows->filter(function ($row) use ($filterDR, $langCode) {
                $data = $row->getTranslatedData($langCode);
                $dr = (int)($data['dr'] ?? 0);
                [$min, $max] = explode('-', $filterDR);
                return $dr >= (int)$min && $dr <= (int)$max;
            });
        }

        // Apply Disclaimer filter (exact match)
        if ($filterDisclaimer) {
            $rows = $rows->filter(function ($row) use ($filterDisclaimer, $langCode) {
                $data = $row->getTranslatedData($langCode);
                $disclaimer = $data['disclaimer'] ?? '';
                return strcasecmp($disclaimer, $filterDisclaimer) === 0;
            });
        }

        // Apply Backlink filter (Yes = all except No, No = only No)
        if ($filterBacklink) {
            $rows = $rows->filter(function ($row) use ($filterBacklink, $langCode) {
                $data = $row->getTranslatedData($langCode);
                $backlink = strtolower(trim($data['backlink'] ?? ''));

                if (strtolower($filterBacklink) === 'yes') {
                    // Show all rows that have backlink (anything except "no" or empty)
                    return $backlink !== 'no' && $backlink !== '';
                } else {
                    // Show only rows with "No"
                    return $backlink === 'no';
                }
            });
        }

        // Apply Indexing filter (exact match)
        if ($filterIndexing) {
            $rows = $rows->filter(function ($row) use ($filterIndexing, $langCode) {
                $data = $row->getTranslatedData($langCode);
                $indexing = $data['indexing'] ?? '';
                return strcasecmp($indexing, $filterIndexing) === 0;
            });
        }

        // Apply sorting
        if ($sortBy) {
            $rows = $rows->sortBy(function ($row) use ($sortBy, $langCode) {
                $data = $row->getTranslatedData($langCode);
                return $data[$sortBy] ?? '';
            }, SORT_REGULAR, $sortDir === 'desc');
        }

        // Paginate manually
        $perPage = 15;
        $page = request('page', 1);
        $total = $rows->count();

        $paginatedRows = new \Illuminate\Pagination\LengthAwarePaginator(
            $rows->forPage($page, $perPage),
            $total,
            $perPage,
            $page,
            ['path' => request()->url(), 'query' => request()->query()]
        );

        return $paginatedRows;
    }

    /**
     * Get filtered rows for a media-type package
     */
    protected function getFilteredRowsForPackage(Package $package, $columns, string $langCode)
    {
        $query = $package->rows()->with('translations.language');

        $search = request('search');
        $sortBy = request('sort_by');
        $sortDir = request('sort_dir', 'asc');

        // Get all rows first (for filtering by translated content)
        $rows = $query->get();

        // Apply search filter
        if ($search) {
            $rows = $rows->filter(function ($row) use ($search, $langCode) {
                $data = $row->getTranslatedData($langCode);
                foreach ($data as $value) {
                    if (is_string($value) && stripos($value, $search) !== false) {
                        return true;
                    }
                }
                return false;
            });
        }

        // Apply dynamic filters based on filterable columns
        $filterableColumns = $columns->where('is_filterable', true);

        foreach ($filterableColumns as $column) {
            $filterKey = 'filter_' . $column->slug;
            $filterValue = request($filterKey);

            if (!$filterValue) {
                continue;
            }

            $rows = $rows->filter(function ($row) use ($column, $filterValue, $langCode) {
                $data = $row->getTranslatedData($langCode);
                $cellValue = $data[$column->slug] ?? '';

                // Handle based on column type
                if ($column->type === 'number') {
                    // Numeric range filter (e.g., "0-20", "21-40")
                    $numValue = (int) $cellValue;
                    if (strpos($filterValue, '-') !== false) {
                        [$min, $max] = explode('-', $filterValue);
                        return $numValue >= (int)$min && $numValue <= (int)$max;
                    }
                    return $numValue == (int) $filterValue;
                } elseif ($column->type === 'dropdown') {
                    // Exact match for dropdown values
                    return strcasecmp($cellValue, $filterValue) === 0;
                } else {
                    // Text contains match
                    return stripos($cellValue, $filterValue) !== false;
                }
            });
        }

        // Apply sorting
        if ($sortBy) {
            $rows = $rows->sortBy(function ($row) use ($sortBy, $langCode) {
                $data = $row->getTranslatedData($langCode);
                return $data[$sortBy] ?? '';
            }, SORT_REGULAR, $sortDir === 'desc');
        }

        // Paginate manually
        $perPage = 15;
        $page = request('page', 1);
        $total = $rows->count();

        $paginatedRows = new \Illuminate\Pagination\LengthAwarePaginator(
            $rows->forPage($page, $perPage),
            $total,
            $perPage,
            $page,
            ['path' => request()->url(), 'query' => request()->query()]
        );

        return $paginatedRows;
    }
}
